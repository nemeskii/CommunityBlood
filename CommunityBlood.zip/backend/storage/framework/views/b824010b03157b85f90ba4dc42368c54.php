<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
</head>
<body style="margin:0; padding:0; background:#f4f1ec; font-family: Arial, sans-serif;">
    <table width="100%" cellpadding="0" cellspacing="0" style="padding: 40px 0;">
        <tr>
            <td align="center">
                <table width="480" cellpadding="0" cellspacing="0" style="background:#ffffff; border:1px solid #e0dcd3; border-radius:6px; padding:40px;">
                    <tr>
                        <td>
                            <p style="font-size:12px; letter-spacing:0.1em; text-transform:uppercase; color:#ab1d2e; margin:0 0 8px;">
                                CommunityBlood
                            </p>
                            <h2 style="margin:0 0 16px; color:#1a1a1a;">A donor has been found</h2>
                            <p style="font-size:15px; line-height:1.6; color:#444; margin:0 0 16px;">
                                Hi <?php echo e($bloodRequest->requester_name); ?>, good news — we've matched a potential
                                <strong><?php echo e($bloodRequest->blood_group); ?></strong> donor to your blood request and
                                they've been notified. Once they confirm, we'll email you their contact details
                                so you can coordinate directly.
                            </p>
                            <p style="font-size:15px; line-height:1.6; color:#444; margin:0 0 28px;">
                                We've attached a PDF with your reference code — keep it handy, you'll need to
                                show it at the hospital when you go to receive blood.
                            </p>
                            <p style="font-size:13px; color:#888; margin:0;">
                                Reference code: <strong><?php echo e($bloodRequest->reference_code); ?></strong>
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
<?php /**PATH E:\CommunityBlood\backend\resources\views/emails/requester-match.blade.php ENDPATH**/ ?>