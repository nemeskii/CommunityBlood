<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
</head>
<body style="margin:0; padding:0; background:#f4f1ec; font-family: Arial, sans-serif;">
    <table width="100%" cellpadding="0" cellspacing="0" style="padding: 40px 0;">
        <tr>
            <td align="center">
                <table width="480" cellpadding="0" cellspacing="0" style="background:#ffffff; border:1px solid #e0dcd3; border-radius:6px; padding:40px;">
                    <tr>
                        <td>
                            <p style="font-size:12px; letter-spacing:0.1em; text-transform:uppercase; color:#ab1d2e; margin:0 0 8px;">
                                CommunityBlood
                            </p>
                            <h2 style="margin:0 0 16px; color:#1a1a1a;">You've been matched to a blood request</h2>
                            <p style="font-size:15px; line-height:1.6; color:#444; margin:0 0 16px;">
                                Hi <?php echo e($donor->full_name); ?>, someone nearby needs <strong><?php echo e($bloodRequest->blood_group); ?></strong> blood
                                <?php if($bloodRequest->city): ?>
                                    in <?php echo e($bloodRequest->city); ?>

                                <?php endif; ?>
                                and you've been matched as a potential donor. We've attached a PDF with the full
                                details and your reference code.
                            </p>
                            <table cellpadding="0" cellspacing="0">
                                <tr>
                                    <td style="background:#ab1d2e; border-radius:4px;">
                                        <a href="<?php echo e($confirmUrl); ?>" style="display:inline-block; padding:14px 28px; color:#ffffff; text-decoration:none; font-weight:bold; font-size:15px;">
                                            Confirm or decline
                                        </a>
                                    </td>
                                </tr>
                            </table>
                            <p style="font-size:13px; color:#888; margin:28px 0 0;">
                                Please respond as soon as you can so we can let the requester know either way.
                            </p>
                            <p style="font-size:12px; color:#aaa; margin:20px 0 0; word-break:break-all;">
                                Or copy this link: <?php echo e($confirmUrl); ?>

                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
<?php /**PATH E:\CommunityBlood\backend\resources\views/emails/donor-match.blade.php ENDPATH**/ ?>