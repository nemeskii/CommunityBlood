<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('donations', function (Blueprint $table) {
            // Shown to the donor as their "card" for this donation trip.
            $table->string('reference_code', 20)->nullable()->unique()->after('id');

            $table->foreignId('hospital_id')
                ->nullable()
                ->after('status')
                ->constrained('hospitals')
                ->nullOnDelete();
            $table->timestamp('verified_at')->nullable()->after('hospital_id');
        });
    }

    public function down(): void
    {
        Schema::table('donations', function (Blueprint $table) {
            $table->dropColumn('verified_at');
            $table->dropConstrainedForeignId('hospital_id');
            $table->dropColumn('reference_code');
        });
    }
};
